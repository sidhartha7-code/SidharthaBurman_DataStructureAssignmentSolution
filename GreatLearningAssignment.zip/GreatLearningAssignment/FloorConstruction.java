public class FloorConstruction {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);

        System.out.println("Enter the total no of floors in the building");
        Scanner totalFloor=sc.nextInt();
         int[] floorsize=new int[totalFloor];

        for (int i = 0; i < totalFloor-1; i++) {
            System.out.println("Enter the floor size on day "+(i+1));
            floorsize[i]=sc.nextInt();
        }

        for (int i = 0; i < floorsize.length; i++) {
            System.out.print(floorsize[i]+" ");
        }
    }
}
